﻿using System;
namespace CSharpFundas
{
    public class Program3
    {
        static void Main(string[] args)
        {
            Console.WriteLine("I am in the third program");
        }

    }
}
