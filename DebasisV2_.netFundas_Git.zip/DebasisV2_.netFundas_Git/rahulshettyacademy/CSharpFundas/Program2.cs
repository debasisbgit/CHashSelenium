﻿using System;
using CSharpFundas;

Console.WriteLine("I am in the second program");

Program p = new Program();
p.getData();







//Global scope of Main