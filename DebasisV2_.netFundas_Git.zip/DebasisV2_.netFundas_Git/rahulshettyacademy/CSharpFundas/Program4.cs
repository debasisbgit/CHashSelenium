﻿using System;
namespace CSharpFundas
{
    public class Program4
    {

        String name;

        public void SetData()

        {

            Console.WriteLine("I am in the parent method of program 4");
        }
    }
}
